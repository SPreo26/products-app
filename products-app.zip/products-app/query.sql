#sql_mode statements make sure there are no group_by errors
SET GLOBAL sql_mode = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
SET SESSION sql_mode = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
SELECT customers.id AS customer_id, customers.first_name AS customer_first_name, categories.id AS category_id, categories.name AS categoriy_name, SUM(order_products.number_purchased) AS number_purchased 
FROM `customers` 
  INNER JOIN `orders` ON `orders`.`customer_id` = `customers`.`id` 
  INNER JOIN `order_products` ON `order_products`.`order_id` = `orders`.`id` 
  INNER JOIN `products` ON `products`.`id` = `order_products`.`product_id` 
  INNER JOIN `product_categories` ON `product_categories`.`product_id` = `products`.`id` 
  INNER JOIN `categories` ON `categories`.`id` = `product_categories`.`category_id` 
  WHERE (first_name = 'John' AND categories.name = 'Bouquets')