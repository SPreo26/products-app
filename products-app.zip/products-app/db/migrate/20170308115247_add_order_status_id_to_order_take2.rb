class AddOrderStatusIdToOrderTake2 < ActiveRecord::Migration
  def change
    add_reference :orders, :order_statuses, index: true
  end
end
