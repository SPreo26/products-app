class AddOrderStatusIdToOrder < ActiveRecord::Migration
  #abandoned MUST redo in order after creation of both tables
  # def change
  #   add_reference :orders, :order_statuses, index: true, foreign_key: true
  # end
end
