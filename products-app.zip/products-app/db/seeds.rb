Category.create!([
  {name: "Bouquets"},
  {name: "Tools"}
])
Customer.create!([
  {first_name: "John", last_name: "Kimble"},
  {first_name: "John", last_name: "Campbell"}
])
Order.create!([
  {customer_id: 1, order_status_id: 1},
  {customer_id: 2, order_status_id: 2}
])
OrderProduct.create!([
  {order_id: 1, product_id: 1, number_purchased: 2},
  {order_id: 1, product_id: 2, number_purchased: 3},
  {order_id: 1, product_id: 3, number_purchased: 4},
  {order_id: 2, product_id: 2, number_purchased: 5}
])
OrderStatus.create!([
  {name: "waiting for delivery"},
  {name: "in transit"},
  {name: "delivered"}
])
Product.create!([
  {name: "Red Basic Flowers", price: 10.99},
  {name: "Bouquet of Carnivorous Flowers", price: 50.99},
  {name: "Hammer", price: 6.99}
])
ProductCategory.create!([
  {product_id: 1, category_id: 1},
  {product_id: 2, category_id: 1},
  {product_id: 3, category_id: 2}
])
