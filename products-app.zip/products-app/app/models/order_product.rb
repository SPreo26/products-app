class OrderProduct < ActiveRecord::Base
  belongs_to :order
  belongs_to :product

  def self.time_interval_order_items(date,time_step_duration)
    time_interval_order_items = OrderProduct.joins("INNER JOIN products ON products.id = order_products.product_id INNER JOIN orders ON orders.id = order_products.order_id INNER JOIN customers ON customers.id = orders.customer_id")#strange errors encountered when using Rails associations so using SQL
      .select("orders.id AS order_id, orders.created_at AS order_date_time, products.id AS product_id, products.name AS item, order_products.number_purchased, customers.id AS customer_id, customers.first_name, customers.last_name")
      .where("DATE(order_products.created_at) >= ? AND DATE(order_products.created_at) < ?", date, date+time_step_duration)
      .as_json
    time_interval_order_items.each do |order_item|
      order_item.delete("id")#garbage pair id: nil returned by query
    end
    return time_interval_order_items
  end
end
