class Order < ActiveRecord::Base
  belongs_to :customer
  belongs_to :order_status
  has_many :order_products
  has_many :products, through: :order_products
end
