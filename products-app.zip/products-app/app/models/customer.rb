class Customer < ActiveRecord::Base
  has_many :orders
  def category_order_count(category)
    return Customer.joins({orders:{products: :categories}})
    .where("first_name = ? AND categories.name = ?", self.first_name, category)
    .select("customers.id, customers.first_name, categories.id, categories.name, SUM(order_products.number_purchased)")
  end

  def self.orders_for_a_customer(first_name,last_name)
    orders_for_a_customer = Customer.joins("INNER JOIN orders ON orders.customer_id = customers.id INNER JOIN order_products ON order_products.order_id = orders.id INNER JOIN products ON products.id = order_products.product_id")#strange errors encountered when using Rails associations so using SQL
      .select("customers.id AS customer_id, customers.first_name, customers.last_name, order_products.created_at AS item_order_date, products.name AS item, products.price")
      .where("customers.first_name=? AND customers.last_name=?",first_name,last_name)
      .as_json
    orders_for_a_customer.each do |order_item|
      order_item.delete("id")#garbage pair id: nil returned by query
    end
    return orders_for_a_customer
  end
end
