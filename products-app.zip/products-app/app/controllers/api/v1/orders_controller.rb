class Api::V1::OrdersController < ApplicationController
  rescue_from Exception, :with => :render_500_json

  before_action :set_vars

  def products_sold_over_dates
    start_date = params[:start_date].to_date
    end_date = params[:end_date].to_date
    if start_date && end_date
      if start_date.class != Date ||
        end_date.class != Date
        @params_invalid=true
        render_json_data and return
      end

      time_step = params[:time_step]
      if @valid_time_steps.include?(time_step)
        time_step_duration = 1.send(time_step)#e.g. "week" => 1.week
        start_date = start_date.send("beginning_of_"+time_step).to_date#e.g if time_step is "week", date is rewound to beginning of week
        end_date = end_date.send("end_of_"+time_step).to_date
      else
        @params_invalid = true
        render_json_data and return
      end
      @data = []
      (start_date..end_date).time_step(time_step_duration).each do |date|
      #time_step method is from core_extensions gem
        time_interval_order_items =  OrderProduct.time_interval_order_items(date,time_step_duration)
        

        @data << {start_date: date, end_date: date+time_step_duration, orders: time_interval_order_items}
      end
      @data
    else
      @params_missing = true
    end
    render_json_data
  end

  def orders_for_a_customer
    if params[:first_name] && params[:last_name]
      first_name = params[:first_name]
      last_name = params[:last_name]
      #currently looking up customer by first_name and last_name; these may not be unique, but as the intended implementation of this API endpoint is unclear (should a customer be logged in, or is this an admin tool?), these are just used as proof of concept identifiers
      @data = Customer.orders_for_a_customer(first_name,last_name)
    else
      @params_missing = true
    end
    render_json_data
  end

  private 
  def set_vars
    @valid_time_steps = ["day","week","month"]
  end

  def render_json_data
    respond_to do |format|
      format.json do 
        if @data
          render json: @data
        else
          if @params_missing
            render json: {message: "Error: Some parameters are missing"}, status: 400
          elsif @params_invalid
            render json: {message: "Error: Some Parameters are unprocessible"}, status: 422
          else
            render json: {message: "Error: unknown"}, status: 400#if this is ever reached, there is a bug as the other error code case fell through
          end
        end
      end
    end
    return true
  end

  def render_500_json(exception)
    @exception = exception
    render :json => {message: "Server error"}, :status => 500
  end

end
